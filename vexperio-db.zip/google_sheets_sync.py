"""
Google Sheets → PostgreSQL sync.
Reads every sheet from the France Mapping spreadsheet and upserts into the DB.

Run manually:
    python google_sheets_sync.py

Or POST /sync/pull  to trigger via API.

Requires:
  GOOGLE_CREDENTIALS_PATH  path to service-account JSON (default: credentials.json)
  GOOGLE_SPREADSHEET_ID    from the Sheets URL  (…/spreadsheets/d/<ID>/…)
"""

import os
import re
import logging
import pandas as pd
from datetime import time
from io import StringIO

import gspread
from google.oauth2.service_account import Credentials
from sqlalchemy.orm import Session

from api.database import SessionLocal
from api import models

logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(message)s")
log = logging.getLogger("sheets_sync")

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets.readonly",
    "https://www.googleapis.com/auth/drive.readonly",
]

CREDENTIALS_PATH = os.getenv("GOOGLE_CREDENTIALS_PATH", "credentials.json")
SPREADSHEET_ID   = os.getenv("GOOGLE_SPREADSHEET_ID", "")


# ── helpers (same as import_excel.py) ────────────────────────────────────────

def clean_str(v) -> str | None:
    if v is None:
        return None
    s = str(v).strip()
    return None if s in ("", "—", "-", "nan", "None") else s


def clean_price(v) -> float | None:
    s = clean_str(v)
    if s is None:
        return None
    try:
        return float(s.replace(",", ""))
    except ValueError:
        return None


def parse_dock_times(v) -> tuple[time | None, time | None]:
    s = clean_str(v)
    if not s:
        return None, None
    m = re.match(r"(\d{1,2}):(\d{2})\s*[-–]\s*(\d{1,2}):(\d{2})", s)
    if m:
        return time(int(m.group(1)), int(m.group(2))), time(int(m.group(3)), int(m.group(4)))
    return None, None


def upsert_ship(db: Session, name: str) -> int:
    name = name.strip()
    obj = db.query(models.Ship).filter_by(name=name).first()
    if not obj:
        obj = models.Ship(name=name)
        db.add(obj)
        db.flush()
    return obj.ship_id


def get_shorex_id(db: Session, name) -> int | None:
    s = clean_str(name)
    if not s:
        return None
    obj = db.query(models.ShoreExcursion).filter_by(name=s).first()
    return obj.shorex_id if obj else None


def get_platform_id(db: Session, name: str) -> int | None:
    name_map = {
        "vexperio": "Vexperio",
        "getyourguide": "GetYourGuide",
        "gyg": "GetYourGuide",
        "viator": "Viator",
        "pe": "Project Expedition",
        "project expedition": "Project Expedition",
    }
    canonical = name_map.get(name.lower().strip(), name.strip())
    obj = db.query(models.Platform).filter_by(name=canonical).first()
    return obj.platform_id if obj else None


# ── Google Sheets client ──────────────────────────────────────────────────────

def get_client() -> gspread.Client:
    if os.path.exists(CREDENTIALS_PATH):
        creds = Credentials.from_service_account_file(CREDENTIALS_PATH, scopes=SCOPES)
    else:
        import google.auth
        creds, _ = google.auth.default(scopes=SCOPES)
    return gspread.authorize(creds)


def sheet_to_df(ws: gspread.Worksheet) -> pd.DataFrame:
    """Download a worksheet and return a DataFrame (header = row 1)."""
    rows = ws.get_all_values()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows[1:], columns=rows[0])
    df.replace({"": None, "—": None, "-": None}, inplace=True)
    return df


# ── sheet syncers ─────────────────────────────────────────────────────────────

def sync_vexperio(db: Session, ws: gspread.Worksheet) -> dict:
    df = sheet_to_df(ws)
    df.columns = ["tour_name", "tour_id", "shorex_name", "option_id", "option_name",
                  "status", "private", "vex_price", "link", "ship_name"]
    df = df.dropna(subset=["tour_id", "option_id"])

    tours_upserted = options_upserted = 0

    for _, row in df.iterrows():
        try:
            tid = int(float(str(row["tour_id"])))
            oid = int(float(str(row["option_id"])))
        except (ValueError, TypeError):
            continue

        shorex_id = get_shorex_id(db, row["shorex_name"])

        # tour — insert only (name/status rarely changes from sheet)
        t = db.query(models.Tour).filter_by(tour_id=tid).first()
        if not t:
            tour_name = clean_str(row["tour_name"])
            if tour_name:
                db.add(models.Tour(
                    tour_id=tid,
                    shorex_id=shorex_id,
                    name=tour_name,
                    status=clean_str(row["status"]) or "Draft",
                    link=clean_str(row["link"]),
                ))
                db.flush()
                tours_upserted += 1
        else:
            # update mutable fields
            changed = False
            new_status = clean_str(row["status"])
            if new_status and t.status != new_status:
                t.status = new_status
                changed = True
            new_link = clean_str(row["link"])
            if t.link != new_link:
                t.link = new_link
                changed = True
            if changed:
                tours_upserted += 1

        # ship
        ship_name = clean_str(row["ship_name"])
        ship_id = None
        if ship_name and ship_name.lower() not in ("combined tour",):
            ship_id = upsert_ship(db, ship_name)

        # option — upsert base_price, link, is_private, ship_id
        opt = db.query(models.TourOption).filter_by(option_id=oid).first()
        if not opt:
            opt_name = clean_str(row["option_name"])
            if opt_name:
                db.add(models.TourOption(
                    option_id=oid,
                    tour_id=tid,
                    name=opt_name,
                    is_private=(str(row.get("private", "")).strip().lower() == "yes"),
                    ship_id=ship_id,
                    base_price=clean_price(row["vex_price"]),
                    link=clean_str(row["link"]),
                ))
                db.flush()
                options_upserted += 1
        else:
            changed = False
            new_price = clean_price(row["vex_price"])
            if new_price is not None and opt.base_price != new_price:
                opt.base_price = new_price
                changed = True
            new_link = clean_str(row["link"])
            if opt.link != new_link:
                opt.link = new_link
                changed = True
            if changed:
                options_upserted += 1

    db.commit()
    return {"tours_upserted": tours_upserted, "options_upserted": options_upserted}


def sync_platform_tours(db: Session, ws: gspread.Worksheet, platform_key: str, cols: list, id_col: str, opt_id_col: str | None) -> dict:
    """Generic upsert for GYG / Viator / PE platform tour sheets."""
    df = sheet_to_df(ws)
    if len(df.columns) < len(cols):
        log.warning("Sheet '%s' has fewer columns than expected — skipping", ws.title)
        return {}
    df = df.iloc[:, :len(cols)]
    df.columns = cols
    df = df.dropna(subset=[id_col])

    platform_id = get_platform_id(db, platform_key)
    if not platform_id:
        return {}

    tours_added = options_added = 0

    for _, row in df.iterrows():
        ext_id = clean_str(row[id_col])
        if not ext_id:
            continue

        tour_name = clean_str(row.get("tour_name") or row.get("gyg_tour_name") or row.get("viator_tour_name") or "")
        if not tour_name:
            continue

        # resolve linked vex tour
        vex_tid = None
        for col in ("vex_tour_id",):
            if col in row and clean_str(row.get(col)):
                try:
                    vex_tid = int(float(str(row[col])))
                except (ValueError, TypeError):
                    pass

        pt = db.query(models.PlatformTour).filter_by(platform_id=platform_id, external_id=ext_id).first()
        if not pt:
            pt = models.PlatformTour(
                platform_id=platform_id,
                external_id=ext_id,
                name=tour_name,
                link=clean_str(row.get("link")),
                status="Active",
                tour_id=vex_tid,
            )
            db.add(pt)
            db.flush()
            tours_added += 1
        else:
            if vex_tid and pt.tour_id != vex_tid:
                pt.tour_id = vex_tid
            if clean_str(row.get("link")) and pt.link != clean_str(row.get("link")):
                pt.link = clean_str(row.get("link"))

        # option
        opt_name_col = next((c for c in ("gyg_option_name", "viator_option_name", "option_name") if c in row.index), None)
        opt_name = clean_str(row.get(opt_name_col)) if opt_name_col else None
        if not opt_name:
            continue

        # vex_option_id
        vex_oid = None
        if "vex_option_id" in row and clean_str(row.get("vex_option_id")):
            try:
                candidate = int(float(str(row["vex_option_id"])))
                if db.query(models.TourOption).filter_by(option_id=candidate).first():
                    vex_oid = candidate
            except (ValueError, TypeError):
                pass

        ext_oid = clean_str(row.get(opt_id_col)) if opt_id_col and opt_id_col in row else None

        existing_po = None
        if ext_oid:
            existing_po = db.query(models.PlatformOption).filter_by(
                platform_tour_id=pt.platform_tour_id, external_option_id=ext_oid
            ).first()
        else:
            existing_po = db.query(models.PlatformOption).filter_by(
                platform_tour_id=pt.platform_tour_id, name=opt_name
            ).first()

        if not existing_po:
            ship_name = clean_str(row.get("ship_name"))
            ship_id = upsert_ship(db, ship_name) if ship_name and ship_name.lower() != "combined tour" else None
            db.add(models.PlatformOption(
                platform_tour_id=pt.platform_tour_id,
                external_option_id=ext_oid,
                name=opt_name,
                vex_option_id=vex_oid,
                ship_id=ship_id,
                link=clean_str(row.get("link")),
            ))
            db.flush()
            options_added += 1
        else:
            if vex_oid and existing_po.vex_option_id != vex_oid:
                existing_po.vex_option_id = vex_oid

    db.commit()
    return {"tours_added": tours_added, "options_added": options_added}


def sync_schedules(db: Session, ws: gspread.Worksheet) -> dict:
    df = sheet_to_df(ws)
    df.columns = ["date", "ship", "docking_times", "port", "start", "tour", "tour_type", "duration", "status"]
    df = df.dropna(subset=["date", "ship"])

    docking_map: dict = {}
    schedules_added = 0

    for _, row in df.iterrows():
        ship_name = clean_str(row["ship"])
        if not ship_name:
            continue

        try:
            dep_date = pd.Timestamp(str(row["date"])).date()
        except Exception:
            continue

        ship_id = upsert_ship(db, ship_name)
        port_obj = db.query(models.Port).filter_by(name=str(row.get("port", "")).strip()).first()
        if not port_obj:
            continue

        key = (ship_id, dep_date)
        if key not in docking_map:
            docking = db.query(models.ShipDocking).filter_by(ship_id=ship_id, date=dep_date).first()
            if not docking:
                dock_start, dock_end = parse_dock_times(row["docking_times"])
                docking = models.ShipDocking(
                    ship_id=ship_id, port_id=port_obj.port_id,
                    date=dep_date, dock_start=dock_start, dock_end=dock_end,
                )
                db.add(docking)
                db.flush()
            docking_map[key] = docking.docking_id

        docking_id = docking_map[key]
        shorex_id = get_shorex_id(db, row["tour"])
        if not shorex_id:
            continue

        start_t = None
        try:
            start_t = pd.Timestamp(str(row["start"])).time()
        except Exception:
            pass

        tour_type = clean_str(row["tour_type"]) or "Shared"
        status = clean_str(row["status"]) or "confirmed"
        duration = None
        try:
            duration = int(float(str(row["duration"])))
        except (ValueError, TypeError):
            pass

        exists = db.query(models.TourSchedule).filter_by(
            docking_id=docking_id, shorex_id=shorex_id,
            tour_type=tour_type, start_time=start_t,
        ).first()
        if not exists:
            db.add(models.TourSchedule(
                docking_id=docking_id, shorex_id=shorex_id,
                start_time=start_t, tour_type=tour_type,
                duration_hours=duration, status=status,
            ))
            schedules_added += 1

    db.commit()
    return {"dockings": len(docking_map), "schedules_added": schedules_added}


def sync_schedule_entries(db: Session, ws: gspread.Worksheet, platform_key: str, cols: list, option_col: str, platform_col: str | None) -> dict:
    df = sheet_to_df(ws)
    if len(df.columns) < len(cols):
        return {}
    df = df.iloc[:, :len(cols)]
    df.columns = cols
    df = df.dropna(subset=["date", "ship"])

    platform_id = get_platform_id(db, platform_key)
    added = updated = 0

    for _, row in df.iterrows():
        ship_name = clean_str(row["ship"])
        if not ship_name:
            continue

        ship_obj = db.query(models.Ship).filter_by(name=ship_name).first()
        if not ship_obj:
            continue

        try:
            dep_date = pd.Timestamp(str(row["date"])).date()
        except Exception:
            continue

        docking = db.query(models.ShipDocking).filter_by(ship_id=ship_obj.ship_id, date=dep_date).first()
        if not docking:
            continue

        shorex_id = get_shorex_id(db, row.get("shorex_name"))
        if not shorex_id:
            continue

        schedule = db.query(models.TourSchedule).filter_by(
            docking_id=docking.docking_id, shorex_id=shorex_id
        ).first()
        if not schedule:
            continue

        vex_oid = None
        if option_col in row and clean_str(row.get(option_col)):
            try:
                candidate = int(float(str(row[option_col])))
                if db.query(models.TourOption).filter_by(option_id=candidate).first():
                    vex_oid = candidate
            except (ValueError, TypeError):
                pass

        platform_option_id = None
        if platform_col and platform_id and platform_col in row:
            ext_oid = clean_str(row.get(platform_col))
            if ext_oid:
                po = db.query(models.PlatformOption).join(models.PlatformTour).filter(
                    models.PlatformTour.platform_id == platform_id,
                    models.PlatformOption.external_option_id == ext_oid,
                ).first()
                if po:
                    platform_option_id = po.platform_option_id

        reviewed_val = str(row.get("reviewed", "")).strip().lower() in ("true", "1", "yes")

        # look for existing entry by schedule + vex_option or platform_option
        entry = None
        if vex_oid:
            entry = db.query(models.SchedulePlatformEntry).filter_by(
                schedule_id=schedule.schedule_id, vex_option_id=vex_oid
            ).first()
        elif platform_option_id:
            entry = db.query(models.SchedulePlatformEntry).filter_by(
                schedule_id=schedule.schedule_id, platform_option_id=platform_option_id
            ).first()

        if not entry:
            entry = models.SchedulePlatformEntry(
                schedule_id=schedule.schedule_id,
                vex_option_id=vex_oid,
                platform_option_id=platform_option_id,
                expected_price=clean_price(row.get("expected_price")),
                entry_status=clean_str(row.get("entry_status")),
                edit_status=clean_str(row.get("edit_status")),
                editor=clean_str(row.get("editor")),
                reviewer=clean_str(row.get("reviewer")),
                reviewed=reviewed_val,
                review=clean_str(row.get("review")),
            )
            db.add(entry)
            db.flush()
            added += 1
        else:
            # only update fields not managed via the API review workflow
            new_price = clean_price(row.get("expected_price"))
            if new_price is not None and entry.expected_price != new_price:
                entry.expected_price = new_price
                updated += 1
            new_status = clean_str(row.get("entry_status"))
            if new_status and entry.entry_status != new_status:
                entry.entry_status = new_status
                updated += 1

        rc = clean_str(row.get("reviewer_comments"))
        if rc:
            existing_note = db.query(models.Note).filter_by(
                entity_type="schedule_platform_entry",
                entity_id=entry.entry_id,
                note_type="review",
                body=rc,
            ).first()
            if not existing_note:
                db.add(models.Note(
                    entity_type="schedule_platform_entry",
                    entity_id=entry.entry_id,
                    note_type="review",
                    body=rc,
                    author=clean_str(row.get("reviewer")),
                ))

    db.commit()
    return {"added": added, "updated": updated}


def sync_pricing(db: Session, ws: gspread.Worksheet) -> dict:
    df = sheet_to_df(ws)
    cols = [
        "shorex_name", "platform_name", "platform_id_ext", "platform",
        "change_details", "price", "commission", "promo_name", "promo_pct",
        "status", "link", "change_status", "editor", "reviewer", "reviewed",
        "review", "reviewer_comments",
    ]
    if len(df.columns) < len(cols):
        return {}
    df = df.iloc[:, :len(cols)]
    df.columns = cols
    df = df.dropna(subset=["shorex_name", "platform"])

    added = updated = 0

    for _, row in df.iterrows():
        shorex_id = get_shorex_id(db, row["shorex_name"])
        platform_id = get_platform_id(db, str(row["platform"]))
        if not shorex_id or not platform_id:
            continue

        ext_id = clean_str(row["platform_id_ext"])
        pt = db.query(models.PlatformTour).filter_by(platform_id=platform_id, external_id=ext_id).first() if ext_id else None
        pt_id = pt.platform_tour_id if pt else None

        reviewed_val = str(row.get("reviewed", "")).strip().lower() in ("true", "1", "yes")

        existing = db.query(models.Pricing).filter_by(
            shorex_id=shorex_id,
            platform_id=platform_id,
            platform_tour_id=pt_id,
        ).first()

        if not existing:
            p = models.Pricing(
                shorex_id=shorex_id,
                platform_id=platform_id,
                platform_tour_id=pt_id,
                price=clean_price(row["price"]),
                commission_pct=clean_price(row["commission"]),
                promo_name=clean_str(row["promo_name"]),
                promo_pct=clean_price(row["promo_pct"]),
                platform_status=clean_str(row["status"]),
                link=clean_str(row["link"]),
                change_status=clean_str(row["change_status"]),
                editor=clean_str(row["editor"]),
                reviewer=clean_str(row["reviewer"]),
                reviewed=reviewed_val,
                review=clean_str(row["review"]),
            )
            db.add(p)
            db.flush()
            added += 1

            for note_type, body_col, author_col in [
                ("change", "change_details", "editor"),
                ("review", "reviewer_comments", "reviewer"),
            ]:
                body = clean_str(row.get(body_col))
                if body:
                    db.add(models.Note(
                        entity_type="pricing", entity_id=p.pricing_id,
                        note_type=note_type, body=body,
                        author=clean_str(row.get(author_col)),
                    ))
        else:
            changed = False
            new_price = clean_price(row["price"])
            if new_price is not None and existing.price != new_price:
                existing.price = new_price
                changed = True
            new_status = clean_str(row["status"])
            if new_status and existing.platform_status != new_status:
                existing.platform_status = new_status
                changed = True
            new_link = clean_str(row["link"])
            if existing.link != new_link:
                existing.link = new_link
                changed = True
            if changed:
                updated += 1

    db.commit()
    return {"added": added, "updated": updated}


# ── orchestrator ──────────────────────────────────────────────────────────────

def run_sync(spreadsheet_id: str = None) -> dict:
    sid = spreadsheet_id or SPREADSHEET_ID
    if not sid:
        raise ValueError("GOOGLE_SPREADSHEET_ID is not set")

    if not os.path.exists(CREDENTIALS_PATH):
        raise FileNotFoundError(f"Credentials file not found: {CREDENTIALS_PATH}")

    log.info("Connecting to Google Sheets…")
    gc = get_client()
    sh = gc.open_by_key(sid)

    ws_map = {ws.title: ws for ws in sh.worksheets()}
    log.info("Found sheets: %s", list(ws_map.keys()))

    db: Session = SessionLocal()
    results: dict = {}

    try:
        # 1. Vexperio catalog
        if "Vexperio" in ws_map:
            log.info("[1/7] Syncing Vexperio catalog…")
            results["vexperio"] = sync_vexperio(db, ws_map["Vexperio"])
            log.info("      %s", results["vexperio"])

        # 2. GYG
        if "GYGVexperio" in ws_map:
            log.info("[2/7] Syncing GYG platform tours…")
            gyg_cols = ["gyg_tour_name", "gyg_tour_id", "gyg_option_name", "gyg_option_id",
                        "vex_option_id", "vex_option_name", "vex_price", "shore_name", "link", "ship_name"]
            results["gyg"] = sync_platform_tours(db, ws_map["GYGVexperio"], "GetYourGuide",
                                                  gyg_cols, "gyg_tour_id", "gyg_option_id")
            log.info("      %s", results["gyg"])

        # 3. Viator
        if "ViatorVexperio" in ws_map:
            log.info("[3/7] Syncing Viator platform tours…")
            viat_cols = ["viator_tour_name", "viator_tour_id", "viator_option_name",
                         "vex_tour_id", "vex_option_id", "vex_option_name",
                         "shorex_name", "link", "ship_name"]
            results["viator"] = sync_platform_tours(db, ws_map["ViatorVexperio"], "Viator",
                                                     viat_cols, "viator_tour_id", None)
            log.info("      %s", results["viator"])

        # 4. France Shared Schedule (dockings + tour_schedules)
        if "France Shared Schedule" in ws_map:
            log.info("[4/7] Syncing ship dockings & tour schedules…")
            results["schedules"] = sync_schedules(db, ws_map["France Shared Schedule"])
            log.info("      %s", results["schedules"])

        # 5-7. Platform schedule entries
        entry_sheets = {
            "Vexperio - schedule and pricing": {
                "platform": "Vexperio",
                "cols": ["date", "ship", "start_time", "port", "shorex_name", "tour_name",
                         "option_name", "vex_option_id", "expected_price", "entry_status",
                         "edit_status", "editor", "reviewer", "reviewed", "review", "reviewer_comments"],
                "option_col": "vex_option_id", "platform_col": None,
            },
            "Viator - schedule and pricing": {
                "platform": "Viator",
                "cols": ["date", "ship", "start_time", "port", "shorex_name", "viator_tour_name",
                         "viator_option_name", "viator_id", "vex_option_id", "expected_price",
                         "entry_status", "edit_status", "editor", "reviewer", "reviewed", "review", "reviewer_comments"],
                "option_col": "vex_option_id", "platform_col": "viator_id",
            },
            "GYG - schedule and pricing": {
                "platform": "GetYourGuide",
                "cols": ["date", "ship", "start_time", "port", "shorex_name", "gyg_tour_name",
                         "gyg_option_name", "gyg_option_id", "vex_option_id", "expected_price",
                         "entry_status", "edit_status", "editor", "reviewer", "reviewed", "review", "reviewer_comments"],
                "option_col": "vex_option_id", "platform_col": "gyg_option_id",
            },
        }

        for i, (sheet_name, cfg) in enumerate(entry_sheets.items(), start=5):
            if sheet_name in ws_map:
                log.info("[%d/7] Syncing '%s'…", i, sheet_name)
                r = sync_schedule_entries(
                    db, ws_map[sheet_name],
                    cfg["platform"], cfg["cols"],
                    cfg["option_col"], cfg["platform_col"],
                )
                results[sheet_name] = r
                log.info("      %s", r)

        # Pricing sheet
        if "Pricing" in ws_map:
            log.info("[7/7] Syncing Pricing…")
            results["pricing"] = sync_pricing(db, ws_map["Pricing"])
            log.info("      %s", results["pricing"])

    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

    log.info("Sync complete.")
    return results


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    run_sync()
