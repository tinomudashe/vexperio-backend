// Paste this into Google Apps Script (Extensions → Apps Script)
// Then set up an installable trigger: Triggers → Add Trigger
//   Function: syncOnEdit
//   Event source: From spreadsheet
//   Event type: On edit

var CLOUD_RUN_URL = 'PASTE_CLOUD_RUN_URL_HERE';

function syncOnEdit(e) {
  try {
    UrlFetchApp.fetch(CLOUD_RUN_URL + '/sync/pull', {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify({}),
      muteHttpExceptions: true
    });
  } catch (err) {
    console.log('Sync error: ' + err.message);
  }
}

// Run this once manually to verify the connection
function testSync() {
  var response = UrlFetchApp.fetch(CLOUD_RUN_URL + '/sync/pull', {
    method: 'post',
    contentType: 'application/json',
    payload: JSON.stringify({}),
    muteHttpExceptions: true
  });
  console.log('Status: ' + response.getResponseCode());
  console.log('Body: ' + response.getContentText());
}
