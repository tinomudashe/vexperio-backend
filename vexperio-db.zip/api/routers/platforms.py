from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from typing import List, Optional
from api.database import get_db
from api.models import Platform, PlatformTour, PlatformOption, PlatformCommission, Discount
from api.schemas import PlatformOut, PlatformTourOut, PlatformOptionOut, CommissionOut, CommissionCreate, DiscountOut, DiscountCreate

router = APIRouter(tags=["platforms"])


# ── Platforms ───────────────────────────────────────────────────────────────

@router.get("/platforms", response_model=List[PlatformOut])
def list_platforms(db: Session = Depends(get_db)):
    return db.query(Platform).all()


# ── Platform Tours ──────────────────────────────────────────────────────────

@router.get("/platforms/{platform_id}/tours", response_model=List[PlatformTourOut])
def list_platform_tours(platform_id: int, tour_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(PlatformTour).options(joinedload(PlatformTour.options)).filter(PlatformTour.platform_id == platform_id)
    if tour_id:
        q = q.filter(PlatformTour.tour_id == tour_id)
    return q.all()


@router.get("/platform-tours/{platform_tour_id}", response_model=PlatformTourOut)
def get_platform_tour(platform_tour_id: int, db: Session = Depends(get_db)):
    pt = db.query(PlatformTour).options(joinedload(PlatformTour.options)).filter(
        PlatformTour.platform_tour_id == platform_tour_id
    ).first()
    if not pt:
        raise HTTPException(status_code=404, detail="Platform tour not found")
    return pt


@router.get("/platform-tours/{platform_tour_id}/options", response_model=List[PlatformOptionOut])
def list_platform_options(platform_tour_id: int, db: Session = Depends(get_db)):
    return db.query(PlatformOption).filter(PlatformOption.platform_tour_id == platform_tour_id).all()


# ── Commissions ─────────────────────────────────────────────────────────────

@router.get("/commissions", response_model=List[CommissionOut])
def list_commissions(platform_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(PlatformCommission)
    if platform_id:
        q = q.filter(PlatformCommission.platform_id == platform_id)
    return q.all()


@router.post("/commissions", response_model=CommissionOut)
def create_commission(payload: CommissionCreate, db: Session = Depends(get_db)):
    platform = db.query(Platform).filter(Platform.platform_id == payload.platform_id).first()
    if not platform:
        raise HTTPException(status_code=404, detail="Platform not found")
    if not platform.applies_commission:
        raise HTTPException(status_code=400, detail="Vexperio is in-house and does not have a commission")
    c = PlatformCommission(**payload.model_dump())
    db.add(c)
    db.commit()
    db.refresh(c)
    return c


@router.delete("/commissions/{commission_id}", status_code=204)
def delete_commission(commission_id: int, db: Session = Depends(get_db)):
    c = db.query(PlatformCommission).filter(PlatformCommission.commission_id == commission_id).first()
    if not c:
        raise HTTPException(status_code=404, detail="Commission not found")
    db.delete(c)
    db.commit()


# ── Discounts ───────────────────────────────────────────────────────────────

@router.get("/discounts", response_model=List[DiscountOut])
def list_discounts(status: Optional[str] = "active", platform_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(Discount)
    if status:
        q = q.filter(Discount.status == status)
    if platform_id:
        q = q.filter(Discount.platform_id == platform_id)
    return q.all()


@router.post("/discounts", response_model=DiscountOut)
def create_discount(payload: DiscountCreate, db: Session = Depends(get_db)):
    d = Discount(**payload.model_dump())
    db.add(d)
    db.commit()
    db.refresh(d)
    return d


@router.patch("/discounts/{discount_id}/deactivate", response_model=DiscountOut)
def deactivate_discount(discount_id: int, db: Session = Depends(get_db)):
    d = db.query(Discount).filter(Discount.discount_id == discount_id).first()
    if not d:
        raise HTTPException(status_code=404, detail="Discount not found")
    d.status = "inactive"
    db.commit()
    db.refresh(d)
    return d
