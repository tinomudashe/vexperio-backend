from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
from api.database import get_db
from api.models import Pricing, PricingHistory
from api.schemas import PricingOut, PricingUpdate

router = APIRouter(prefix="/pricing", tags=["pricing"])


@router.get("", response_model=List[PricingOut])
def list_pricing(
    shorex_id: Optional[int] = None,
    platform_id: Optional[int] = None,
    change_status: Optional[str] = None,
    reviewed: Optional[bool] = None,
    db: Session = Depends(get_db)
):
    q = db.query(Pricing)
    if shorex_id:
        q = q.filter(Pricing.shorex_id == shorex_id)
    if platform_id:
        q = q.filter(Pricing.platform_id == platform_id)
    if change_status:
        q = q.filter(Pricing.change_status == change_status)
    if reviewed is not None:
        q = q.filter(Pricing.reviewed == reviewed)
    return q.all()


@router.get("/{pricing_id}", response_model=PricingOut)
def get_pricing(pricing_id: int, db: Session = Depends(get_db)):
    p = db.query(Pricing).filter(Pricing.pricing_id == pricing_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Pricing record not found")
    return p


@router.patch("/{pricing_id}", response_model=PricingOut)
def update_pricing(pricing_id: int, payload: PricingUpdate, db: Session = Depends(get_db)):
    p = db.query(Pricing).filter(Pricing.pricing_id == pricing_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Pricing record not found")

    # snapshot before update
    snapshot = PricingHistory(
        pricing_id=p.pricing_id,
        shorex_id=p.shorex_id,
        platform_id=p.platform_id,
        platform_tour_id=p.platform_tour_id,
        price=p.price,
        commission_pct=p.commission_pct,
        platform_status=p.platform_status,
        change_details=p.change_details,
        change_status=p.change_status,
        editor=p.editor,
        reviewer=p.reviewer,
        review=p.review,
        reviewer_comments=p.reviewer_comments,
    )
    db.add(snapshot)

    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(p, field, value)
    p.reviewed = False
    p.review = None
    p.reviewer = None
    p.reviewer_comments = None

    db.commit()
    db.refresh(p)
    return p


@router.get("/{pricing_id}/history", response_model=List[dict])
def get_pricing_history(pricing_id: int, db: Session = Depends(get_db)):
    rows = db.query(PricingHistory).filter(
        PricingHistory.pricing_id == pricing_id
    ).order_by(PricingHistory.snapshotted_at.desc()).all()
    return [
        {
            "history_id": r.history_id,
            "price": float(r.price) if r.price else None,
            "platform_status": r.platform_status,
            "change_details": r.change_details,
            "change_status": r.change_status,
            "editor": r.editor,
            "review": r.review,
            "snapshotted_at": r.snapshotted_at,
        }
        for r in rows
    ]
