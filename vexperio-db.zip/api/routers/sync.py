from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional
import threading
import time as _time

router = APIRouter(prefix="/sync", tags=["sync"])

_sync_lock = threading.Lock()
_last_result: dict = {}
_running: bool = False


class SyncRequest(BaseModel):
    spreadsheet_id: Optional[str] = None


@router.post("/pull")
def pull_from_sheets(req: SyncRequest, background_tasks: BackgroundTasks):
    """Trigger a Sheets → DB sync. Runs in the background; poll /sync/status."""
    global _running
    if _running:
        raise HTTPException(status_code=409, detail="Sync already in progress")

    background_tasks.add_task(_run_sync_task, req.spreadsheet_id)
    return {"status": "started"}


@router.get("/status")
def sync_status():
    return {"running": _running, "last_result": _last_result}


def _run_sync_task(spreadsheet_id: Optional[str]):
    global _running, _last_result
    with _sync_lock:
        _running = True
        try:
            from google_sheets_sync import run_sync
            result = run_sync(spreadsheet_id)
            _last_result = {"ok": True, "result": result, "ts": _time.time()}
        except Exception as e:
            _last_result = {"ok": False, "error": str(e), "ts": _time.time()}
        finally:
            _running = False
