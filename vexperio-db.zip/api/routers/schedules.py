from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from typing import List, Optional
from datetime import date
from api.database import get_db
from api.models import ShipDocking, TourSchedule, SchedulePlatformEntry
from api.schemas import DockingOut, TourScheduleOut, ScheduleEntryOut, ScheduleEntryUpdate

router = APIRouter(prefix="/schedules", tags=["schedules"])


@router.get("/dockings", response_model=List[DockingOut])
def list_dockings(
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    ship_id: Optional[int] = None,
    port_id: Optional[int] = None,
    db: Session = Depends(get_db)
):
    q = db.query(ShipDocking)
    if date_from:
        q = q.filter(ShipDocking.date >= date_from)
    if date_to:
        q = q.filter(ShipDocking.date <= date_to)
    if ship_id:
        q = q.filter(ShipDocking.ship_id == ship_id)
    if port_id:
        q = q.filter(ShipDocking.port_id == port_id)
    return q.order_by(ShipDocking.date).all()


@router.get("/dockings/{docking_id}", response_model=DockingOut)
def get_docking(docking_id: int, db: Session = Depends(get_db)):
    d = db.query(ShipDocking).filter(ShipDocking.docking_id == docking_id).first()
    if not d:
        raise HTTPException(status_code=404, detail="Docking not found")
    return d


@router.get("/dockings/{docking_id}/tours", response_model=List[TourScheduleOut])
def get_docking_tours(docking_id: int, db: Session = Depends(get_db)):
    return db.query(TourSchedule).options(
        joinedload(TourSchedule.platform_entries)
    ).filter(TourSchedule.docking_id == docking_id).all()


@router.get("", response_model=List[TourScheduleOut])
def list_schedules(
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    shorex_id: Optional[int] = None,
    tour_type: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db)
):
    q = db.query(TourSchedule).options(
        joinedload(TourSchedule.platform_entries),
        joinedload(TourSchedule.docking)
    )
    if shorex_id:
        q = q.filter(TourSchedule.shorex_id == shorex_id)
    if tour_type:
        q = q.filter(TourSchedule.tour_type == tour_type)
    if status:
        q = q.filter(TourSchedule.status == status)
    if date_from or date_to:
        q = q.join(ShipDocking)
        if date_from:
            q = q.filter(ShipDocking.date >= date_from)
        if date_to:
            q = q.filter(ShipDocking.date <= date_to)
    return q.all()


@router.get("/{schedule_id}", response_model=TourScheduleOut)
def get_schedule(schedule_id: int, db: Session = Depends(get_db)):
    s = db.query(TourSchedule).options(
        joinedload(TourSchedule.platform_entries)
    ).filter(TourSchedule.schedule_id == schedule_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Schedule not found")
    return s


@router.patch("/{schedule_id}/entries/{entry_id}", response_model=ScheduleEntryOut)
def update_entry(schedule_id: int, entry_id: int, payload: ScheduleEntryUpdate, db: Session = Depends(get_db)):
    entry = db.query(SchedulePlatformEntry).filter(
        SchedulePlatformEntry.entry_id == entry_id,
        SchedulePlatformEntry.schedule_id == schedule_id
    ).first()
    if not entry:
        raise HTTPException(status_code=404, detail="Entry not found")
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(entry, field, value)
    db.commit()
    db.refresh(entry)
    return entry


@router.patch("/{schedule_id}/cancel", response_model=TourScheduleOut)
def cancel_schedule(schedule_id: int, db: Session = Depends(get_db)):
    s = db.query(TourSchedule).filter(TourSchedule.schedule_id == schedule_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Schedule not found")
    s.status = "Cancelled"
    db.commit()
    db.refresh(s)
    return s
