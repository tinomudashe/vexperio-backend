from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from typing import List, Optional
from api.database import get_db
from api.models import Tour, TourOption, ShoreExcursion, OptionAvailability, OptionStartTime, OptionBlockedPeriod
from api.schemas import TourOut, TourWithOptions, TourOptionOut, AvailabilityOut, AvailabilityIn

router = APIRouter(prefix="/tours", tags=["tours"])


@router.get("", response_model=List[TourOut])
def list_tours(shorex_id: Optional[int] = None, status: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(Tour)
    if shorex_id:
        q = q.filter(Tour.shorex_id == shorex_id)
    if status:
        q = q.filter(Tour.status == status)
    return q.all()


@router.get("/{tour_id}", response_model=TourWithOptions)
def get_tour(tour_id: int, db: Session = Depends(get_db)):
    tour = db.query(Tour).options(joinedload(Tour.options)).filter(Tour.tour_id == tour_id).first()
    if not tour:
        raise HTTPException(status_code=404, detail="Tour not found")
    return tour


@router.get("/{tour_id}/options", response_model=List[TourOptionOut])
def list_options(tour_id: int, is_private: Optional[bool] = None, db: Session = Depends(get_db)):
    q = db.query(TourOption).filter(TourOption.tour_id == tour_id)
    if is_private is not None:
        q = q.filter(TourOption.is_private == is_private)
    return q.all()


@router.get("/{tour_id}/options/{option_id}", response_model=TourOptionOut)
def get_option(tour_id: int, option_id: int, db: Session = Depends(get_db)):
    opt = db.query(TourOption).filter(TourOption.tour_id == tour_id, TourOption.option_id == option_id).first()
    if not opt:
        raise HTTPException(status_code=404, detail="Option not found")
    return opt


@router.get("/{tour_id}/options/{option_id}/availability", response_model=List[AvailabilityOut])
def get_availability(tour_id: int, option_id: int, db: Session = Depends(get_db)):
    opt = db.query(TourOption).filter(TourOption.tour_id == tour_id, TourOption.option_id == option_id).first()
    if not opt:
        raise HTTPException(status_code=404, detail="Option not found")
    return db.query(OptionAvailability).options(
        joinedload(OptionAvailability.start_times),
        joinedload(OptionAvailability.blocked_periods)
    ).filter(OptionAvailability.option_id == option_id).all()


@router.post("/{tour_id}/options/{option_id}/availability", response_model=AvailabilityOut)
def set_availability(tour_id: int, option_id: int, payload: AvailabilityIn, db: Session = Depends(get_db)):
    opt = db.query(TourOption).filter(TourOption.tour_id == tour_id, TourOption.option_id == option_id).first()
    if not opt:
        raise HTTPException(status_code=404, detail="Option not found")

    avail = OptionAvailability(
        option_id=option_id,
        schedule_type=payload.schedule_type,
        valid_from=payload.valid_from,
        valid_to=payload.valid_to,
        mon=payload.mon, tue=payload.tue, wed=payload.wed,
        thu=payload.thu, fri=payload.fri, sat=payload.sat, sun=payload.sun,
        cms_status=payload.cms_status,
    )
    db.add(avail)
    db.flush()

    for t in payload.start_times:
        db.add(OptionStartTime(availability_id=avail.availability_id, start_time=t))
    for bp in payload.blocked_periods:
        db.add(OptionBlockedPeriod(
            availability_id=avail.availability_id,
            date_from=bp.date_from, date_to=bp.date_to, reason=bp.reason
        ))

    db.commit()
    db.refresh(avail)
    return avail
