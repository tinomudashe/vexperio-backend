from pydantic import BaseModel
from typing import Optional, List
from datetime import date, time, datetime
from decimal import Decimal


# ── Shared workflow fields ──────────────────────────────────────────────────

class WorkflowFields(BaseModel):
    edit_status: Optional[str] = None
    editor: Optional[str] = None
    reviewer: Optional[str] = None
    reviewed: bool = False
    review: Optional[str] = None
    reviewer_comments: Optional[str] = None


class ReviewAction(BaseModel):
    reviewer: str
    review: str                        # Approved | Pending | All Good | Clarification Needed
    reviewer_comments: Optional[str] = None


# ── Port ───────────────────────────────────────────────────────────────────

class PortOut(BaseModel):
    port_id: int
    name: str
    model_config = {"from_attributes": True}


# ── Ship ───────────────────────────────────────────────────────────────────

class ShipOut(BaseModel):
    ship_id: int
    name: str
    model_config = {"from_attributes": True}


# ── Platform ───────────────────────────────────────────────────────────────

class PlatformOut(BaseModel):
    platform_id: int
    name: str
    commission_pct: Optional[Decimal]
    applies_commission: bool
    model_config = {"from_attributes": True}


# ── Shore Excursion ────────────────────────────────────────────────────────

class ShoreExcursionOut(BaseModel):
    shorex_id: int
    name: str
    primary_port_id: Optional[int]
    model_config = {"from_attributes": True}


# ── Tour ───────────────────────────────────────────────────────────────────

class TourOut(BaseModel):
    tour_id: int
    shorex_id: int
    name: str
    status: str
    link: Optional[str]
    model_config = {"from_attributes": True}


class TourOptionOut(BaseModel):
    option_id: int
    tour_id: int
    name: str
    is_private: bool
    ship_id: Optional[int]
    base_price: Optional[Decimal]
    link: Optional[str]
    model_config = {"from_attributes": True}


class TourWithOptions(TourOut):
    options: List[TourOptionOut] = []


# ── Option Availability ────────────────────────────────────────────────────

class StartTimeOut(BaseModel):
    start_time_id: int
    start_time: time
    model_config = {"from_attributes": True}


class BlockedPeriodOut(BaseModel):
    blocked_id: int
    date_from: date
    date_to: date
    reason: Optional[str]
    model_config = {"from_attributes": True}


class BlockedPeriodIn(BaseModel):
    date_from: date
    date_to: date
    reason: Optional[str] = None


class AvailabilityOut(BaseModel):
    availability_id: int
    option_id: int
    schedule_type: str
    valid_from: date
    valid_to: Optional[date]
    mon: bool
    tue: bool
    wed: bool
    thu: bool
    fri: bool
    sat: bool
    sun: bool
    cms_status: str
    start_times: List[StartTimeOut] = []
    blocked_periods: List[BlockedPeriodOut] = []
    model_config = {"from_attributes": True}


class AvailabilityIn(BaseModel):
    schedule_type: str = "weekly_recurring"
    valid_from: date
    valid_to: Optional[date] = None
    mon: bool = False
    tue: bool = False
    wed: bool = False
    thu: bool = False
    fri: bool = False
    sat: bool = False
    sun: bool = False
    cms_status: str = "Active"
    start_times: List[time] = []
    blocked_periods: List[BlockedPeriodIn] = []


# ── Platform Tours & Options ───────────────────────────────────────────────

class PlatformOptionOut(BaseModel):
    platform_option_id: int
    platform_tour_id: int
    external_option_id: Optional[str]
    name: str
    vex_option_id: Optional[int]
    ship_id: Optional[int]
    link: Optional[str]
    model_config = {"from_attributes": True}


class PlatformTourOut(BaseModel):
    platform_tour_id: int
    platform_id: int
    external_id: str
    name: str
    link: Optional[str]
    status: Optional[str]
    tour_id: Optional[int]
    options: List[PlatformOptionOut] = []
    model_config = {"from_attributes": True}


# ── Schedule ───────────────────────────────────────────────────────────────

class DockingOut(BaseModel):
    docking_id: int
    ship_id: int
    port_id: int
    date: date
    dock_start: Optional[time]
    dock_end: Optional[time]
    model_config = {"from_attributes": True}


class ScheduleEntryOut(BaseModel):
    entry_id: int
    schedule_id: int
    vex_option_id: Optional[int]
    platform_option_id: Optional[int]
    expected_price: Optional[Decimal]
    entry_status: Optional[str]
    edit_status: Optional[str]
    editor: Optional[str]
    reviewer: Optional[str]
    reviewed: bool
    review: Optional[str]
    model_config = {"from_attributes": True}


class ScheduleEntryUpdate(WorkflowFields):
    expected_price: Optional[Decimal] = None
    entry_status: Optional[str] = None


class TourScheduleOut(BaseModel):
    schedule_id: int
    docking_id: int
    shorex_id: int
    start_time: Optional[time]
    tour_type: str
    duration_hours: Optional[int]
    status: str
    platform_entries: List[ScheduleEntryOut] = []
    model_config = {"from_attributes": True}


# ── Departure ──────────────────────────────────────────────────────────────

class DepartureOut(BaseModel):
    departure_id: int
    option_id: int
    departure_date: date
    start_time: time
    source: str
    availability_id: Optional[int]
    docking_id: Optional[int]
    status: str
    manually_closed: bool
    closed_by: Optional[str]
    closed_at: Optional[datetime]
    close_reason: Optional[str]
    max_pax: Optional[int]
    model_config = {"from_attributes": True}


class DepartureCreate(BaseModel):
    option_id: int
    departure_date: date
    start_time: time
    source: str = "manual"
    availability_id: Optional[int] = None
    docking_id: Optional[int] = None
    max_pax: Optional[int] = None


class DepartureClose(BaseModel):
    closed_by: str
    close_reason: Optional[str] = None


# ── Pricing ────────────────────────────────────────────────────────────────

class PricingOut(BaseModel):
    pricing_id: int
    shorex_id: int
    platform_id: int
    platform_tour_id: Optional[int]
    vex_option_id: Optional[int]
    price: Optional[Decimal]
    commission_pct: Optional[Decimal]
    promo_name: Optional[str]
    promo_pct: Optional[Decimal]
    platform_status: Optional[str]
    link: Optional[str]
    change_status: Optional[str]
    editor: Optional[str]
    reviewer: Optional[str]
    reviewed: bool
    review: Optional[str]
    updated_at: Optional[datetime]
    model_config = {"from_attributes": True}


class PricingUpdate(BaseModel):
    price: Optional[Decimal] = None
    platform_status: Optional[str] = None
    change_status: Optional[str] = None
    editor: Optional[str] = None
    promo_name: Optional[str] = None
    promo_pct: Optional[Decimal] = None


# ── Discount ───────────────────────────────────────────────────────────────

class DiscountOut(BaseModel):
    discount_id: int
    name: str
    platform_id: Optional[int]
    shorex_id: Optional[int]
    tour_id: Optional[int]
    option_id: Optional[int]
    discount_pct: Decimal
    promo_code: Optional[str]
    valid_from: date
    valid_to: Optional[date]
    status: str
    model_config = {"from_attributes": True}


class DiscountCreate(BaseModel):
    name: str
    platform_id: Optional[int] = None
    shorex_id: Optional[int] = None
    tour_id: Optional[int] = None
    option_id: Optional[int] = None
    discount_pct: Decimal
    promo_code: Optional[str] = None
    valid_from: date
    valid_to: Optional[date] = None
    created_by: Optional[str] = None
    notes: Optional[str] = None


# ── Commission ─────────────────────────────────────────────────────────────

class CommissionOut(BaseModel):
    commission_id: int
    platform_id: int
    shorex_id: Optional[int]
    tour_id: Optional[int]
    option_id: Optional[int]
    commission_pct: Decimal
    valid_from: date
    valid_to: Optional[date]
    notes: Optional[str]
    model_config = {"from_attributes": True}


class CommissionCreate(BaseModel):
    platform_id: int
    shorex_id: Optional[int] = None
    tour_id: Optional[int] = None
    option_id: Optional[int] = None
    commission_pct: Decimal
    valid_from: date
    valid_to: Optional[date] = None
    notes: Optional[str] = None


# ── Notes ─────────────────────────────────────────────────────────────────

class NoteOut(BaseModel):
    note_id: int
    entity_type: str
    entity_id: int
    note_type: str
    body: str
    author: Optional[str]
    created_at: datetime
    model_config = {"from_attributes": True}


class NoteCreate(BaseModel):
    note_type: str = "general"         # change | review | general
    body: str
    author: Optional[str] = None


# ── Change Log ─────────────────────────────────────────────────────────────

class ChangeLogOut(BaseModel):
    log_id: int
    entity_type: str
    entity_id: int
    field_name: Optional[str]
    old_value: Optional[str]
    new_value: Optional[str]
    change_details: Optional[str]
    editor: Optional[str]
    edit_status: Optional[str]
    reviewer: Optional[str]
    reviewed: bool
    review: Optional[str]
    reviewer_comments: Optional[str]
    changed_at: datetime
    reviewed_at: Optional[datetime]
    model_config = {"from_attributes": True}
